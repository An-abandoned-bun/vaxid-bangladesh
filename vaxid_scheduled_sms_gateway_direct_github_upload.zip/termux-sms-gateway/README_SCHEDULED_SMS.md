# VaxID Scheduled Android SMS Gateway

This is the scheduled SMS gateway for VaxID Bangladesh.

It sends two types of SMS:

1. Normal website-generated reminders
2. Automatic vaccination reminders sent 7 days, 3 days, and 1 day before the vaccine due date

## Main Feature

If a vaccination record is entered today but the vaccine is due weeks later, the Android gateway will still send reminders at the correct times.

Example:

```text
Vaccination data entered: June 1
Vaccine due date: July 20
SMS sent: July 13, July 17, July 19
```

## Reminder Rules

The system checks `vaccination_records.due_date`.

It sends SMS when the due date is:

```text
today + 7 days
today + 3 days
today + 1 day
```

It skips completed vaccines if the status contains:

```text
completed
complete
given
done
vaccinated
```

## Duplicate Protection

The script creates deterministic reminder IDs such as:

```text
scheduled_childid_vaccine_due_date_7d
```

So the same scheduled reminder is not sent twice.

## Required Environment Variable

Do not hardcode your Firebase API key.

In Termux:

```bash
export FIREBASE_WEB_API_KEY="YOUR_FIREBASE_API_KEY"
```

Run:

```bash
python vaxid_sms_sender.py
```
