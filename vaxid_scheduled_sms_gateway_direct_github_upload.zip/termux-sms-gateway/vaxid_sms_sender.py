"""
VaxID Android SIM SMS Gateway
Scheduled Reminder Version

This Termux script sends:
1. Website-generated reminders where reminders.status == "generated_by_groq"
2. Automatic vaccine reminders 7, 3, and 1 day before vaccination_records.due_date

It avoids duplicate scheduled SMS by creating deterministic reminder IDs.
"""

import os
import re
import time
import requests
import subprocess
from datetime import datetime, timezone, timedelta, date


PROJECT_ID = os.getenv("FIREBASE_PROJECT_ID", "vaxid-32db2")
API_KEY = os.getenv("FIREBASE_WEB_API_KEY", "PASTE_FIREBASE_WEB_API_KEY_HERE")

POLL_SECONDS = int(os.getenv("POLL_SECONDS", "10"))
MAX_SMS_PER_RUN = int(os.getenv("MAX_SMS_PER_RUN", "5"))
REMINDER_DAYS_BEFORE = [7, 3, 1]

BASE = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents"


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def normalize_bd_phone(phone):
    digits = "".join(ch for ch in str(phone or "") if ch.isdigit())

    if digits.startswith("00880"):
        digits = digits[2:]

    if digits.startswith("880"):
        return "+" + digits

    if digits.startswith("88") and digits[2:].startswith("01"):
        return "+" + digits

    if digits.startswith("0"):
        return "+88" + digits

    if len(digits) == 10 and digits.startswith("1"):
        return "+880" + digits

    return "+" + digits


def firestore_value_to_python(value):
    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        return int(value["integerValue"])
    if "doubleValue" in value:
        return float(value["doubleValue"])
    if "booleanValue" in value:
        return bool(value["booleanValue"])
    if "timestampValue" in value:
        return value["timestampValue"]
    if "nullValue" in value:
        return None
    if "arrayValue" in value:
        return [firestore_value_to_python(v) for v in value["arrayValue"].get("values", [])]
    if "mapValue" in value:
        return {k: firestore_value_to_python(v) for k, v in value["mapValue"].get("fields", {}).items()}
    return value


def python_to_firestore_value(value):
    if value is None:
        return {"nullValue": None}
    if isinstance(value, bool):
        return {"booleanValue": value}
    if isinstance(value, int):
        return {"integerValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    return {"stringValue": str(value)}


def dict_to_firestore_fields(data):
    return {"fields": {k: python_to_firestore_value(v) for k, v in data.items()}}


def doc_to_dict(doc):
    fields = doc.get("fields", {})
    return {key: firestore_value_to_python(value) for key, value in fields.items()}


def safe_doc_id(value):
    text = str(value or "").lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text[:450] or "item"


def reminder_id_for_schedule(child_id, vaccine_name, due_date, days_before):
    return safe_doc_id(f"scheduled_{child_id}_{vaccine_name}_{due_date}_{days_before}d")


def firestore_get_doc(collection_name, doc_id):
    url = f"{BASE}/{collection_name}/{doc_id}?key={API_KEY}"
    response = requests.get(url, timeout=20)

    if response.status_code == 404:
        return None

    if response.status_code != 200:
        print(f"Could not load {collection_name}/{doc_id}:", response.text)
        return None

    return doc_to_dict(response.json())


def firestore_patch_doc(collection_name, doc_id, data):
    url = f"{BASE}/{collection_name}/{doc_id}?key={API_KEY}"
    response = requests.patch(url, json=dict_to_firestore_fields(data), timeout=20)

    if response.status_code not in [200, 201]:
        print(f"Failed to write {collection_name}/{doc_id}:", response.text)
        return False

    return True


def update_reminder_status(reminder_id, status, note=""):
    return firestore_patch_doc("reminders", reminder_id, {
        "status": status,
        "sent_at": now_iso(),
        "gateway_note": note
    })


def get_child(child_id):
    return firestore_get_doc("children", child_id)


def run_query(collection_id, where_filter=None, limit=100):
    url = f"{BASE}:runQuery?key={API_KEY}"

    structured = {
        "from": [{"collectionId": collection_id}],
        "limit": limit
    }

    if where_filter:
        structured["where"] = where_filter

    response = requests.post(url, json={"structuredQuery": structured}, timeout=25)
    response.raise_for_status()

    rows = []

    for item in response.json():
        doc = item.get("document")
        if not doc:
            continue

        data = doc_to_dict(doc)
        doc_path = doc["name"]
        doc_id = doc_path.split("/")[-1]
        rows.append({"id": doc_id, "path": doc_path, "data": data})

    return rows


def get_pending_generated_reminders():
    where_filter = {
        "fieldFilter": {
            "field": {"fieldPath": "status"},
            "op": "EQUAL",
            "value": {"stringValue": "generated_by_groq"}
        }
    }

    return run_query("reminders", where_filter, MAX_SMS_PER_RUN)


def get_vaccinations_due_on(due_date_text):
    where_filter = {
        "fieldFilter": {
            "field": {"fieldPath": "due_date"},
            "op": "EQUAL",
            "value": {"stringValue": due_date_text}
        }
    }

    return run_query("vaccination_records", where_filter, 100)


def extract_parent_sms_only(message):
    text = str(message or "").replace("\\n", "\n").replace("\r", " ").strip()
    text = re.sub(r"\s+", " ", text)

    quoted_after_5 = re.findall(
        r"(?:^|\s)5\.\s*[\"“](.+?)[\"”](?=\s*(?:6\.|$))",
        text,
        flags=re.I
    )

    if quoted_after_5:
        sms = quoted_after_5[-1].strip()
    else:
        match = re.search(
            r"(?:^|\s)5\.\s*(?:Parent SMS/message|Parent SMS|SMS/message|Parent message)?\s*:?\s*(.*?)(?=\s*6\.|\Z)",
            text,
            flags=re.S | re.I
        )

        if match:
            sms = match.group(1).strip()
            quoted = re.search(r"[\"“](.+?)[\"”]", sms, flags=re.S)
            if quoted:
                sms = quoted.group(1).strip()
        else:
            sms = text.strip()

    sms = re.sub(r"^\s*5\.\s*", "", sms, flags=re.I)
    sms = re.sub(r"^\s*(Parent SMS/message|Parent SMS|SMS/message|Parent message)\s*:?\s*", "", sms, flags=re.I)
    sms = re.split(r"\s+6\.\s*|\s+Clinic action\s*:?", sms, maxsplit=1, flags=re.I)[0]
    sms = sms.strip().strip("-").strip().strip("\"'“”")
    sms = re.sub(r"\s+", " ", sms).strip()

    if len(sms) > 320:
        sms = sms[:317].rstrip() + "..."

    return sms


def vaccination_is_completed(vaccination):
    status = str(vaccination.get("status") or "").lower().strip()
    completed_words = ["completed", "complete", "given", "done", "vaccinated"]
    return any(word in status for word in completed_words)


def build_scheduled_sms(child, vaccination, days_before):
    child_name = child.get("child_name") or "your child"
    parent_name = child.get("parent_name") or "Parent"
    vaccine = vaccination.get("vaccine_name") or "vaccine"
    due_date_text = vaccination.get("due_date") or "the scheduled date"
    clinic = child.get("preferred_clinic") or vaccination.get("hospital_name") or "your selected vaccination center"

    day_text = "tomorrow" if days_before == 1 else f"in {days_before} days"

    message = (
        f"Dear {parent_name}, reminder: {child_name}'s {vaccine} is due {day_text} "
        f"on {due_date_text}. Please visit {clinic}. If the child is sick, allergic, "
        f"or had an unusual reaction before, consult the doctor first."
    )

    if len(message) > 320:
        message = message[:317].rstrip() + "..."

    return message


def send_sms(phone, message):
    phone = normalize_bd_phone(phone)

    print("Sending SMS to:", phone)
    print("Message:", message)

    subprocess.run(["termux-sms-send", "-n", phone, message], check=True)

    return phone


def process_generated_reminders():
    reminders = get_pending_generated_reminders()

    if not reminders:
        print("No manually generated Groq reminders.")
        return 0

    sent_count = 0

    for reminder in reminders:
        reminder_id = reminder["id"]
        data = reminder["data"]

        child_id = data.get("child_id")
        message = extract_parent_sms_only(data.get("message"))

        if not child_id or not message:
            update_reminder_status(reminder_id, "failed_missing_child_or_message")
            continue

        child = get_child(child_id)

        if not child:
            update_reminder_status(reminder_id, "failed_child_not_found")
            continue

        phone = child.get("parent_phone")

        if not phone:
            update_reminder_status(reminder_id, "failed_no_parent_phone")
            continue

        try:
            sent_to = send_sms(phone, message)
            update_reminder_status(reminder_id, "sent_by_android_sim", f"Sent to {sent_to}")
            sent_count += 1
            print("Manual reminder sent for child:", child_id)

        except Exception as sms_error:
            print("Manual SMS failed:", sms_error)
            update_reminder_status(reminder_id, "failed_sms_send", str(sms_error))

    return sent_count


def process_scheduled_vaccine_reminders():
    today = date.today()
    sent_count = 0

    for days_before in REMINDER_DAYS_BEFORE:
        target_date = today + timedelta(days=days_before)
        target_date_text = target_date.isoformat()

        print(f"Checking vaccines due in {days_before} day(s): {target_date_text}")

        vaccinations = get_vaccinations_due_on(target_date_text)

        for item in vaccinations:
            vaccination = item["data"]
            vaccination_doc_id = item["id"]

            child_id = vaccination.get("child_id")
            vaccine_name = vaccination.get("vaccine_name") or "vaccine"
            due_date_text = vaccination.get("due_date") or target_date_text

            if not child_id:
                continue

            if vaccination_is_completed(vaccination):
                print("Skipping completed vaccination:", vaccination_doc_id)
                continue

            reminder_id = reminder_id_for_schedule(child_id, vaccine_name, due_date_text, days_before)

            if firestore_get_doc("reminders", reminder_id):
                print("Already handled scheduled reminder:", reminder_id)
                continue

            child = get_child(child_id)

            if not child:
                firestore_patch_doc("reminders", reminder_id, {
                    "child_id": child_id,
                    "vaccine_name": vaccine_name,
                    "due_date": due_date_text,
                    "reminder_days_before": days_before,
                    "reminder_type": f"auto_{days_before}_day_vaccine_reminder",
                    "status": "failed_child_not_found",
                    "created_at": now_iso(),
                    "gateway_note": "Child profile not found"
                })
                continue

            phone = child.get("parent_phone")

            if not phone:
                firestore_patch_doc("reminders", reminder_id, {
                    "child_id": child_id,
                    "vaccine_name": vaccine_name,
                    "due_date": due_date_text,
                    "reminder_days_before": days_before,
                    "reminder_type": f"auto_{days_before}_day_vaccine_reminder",
                    "status": "failed_no_parent_phone",
                    "created_at": now_iso(),
                    "gateway_note": "Parent phone not found"
                })
                continue

            message = build_scheduled_sms(child, vaccination, days_before)

            firestore_patch_doc("reminders", reminder_id, {
                "child_id": child_id,
                "vaccine_name": vaccine_name,
                "due_date": due_date_text,
                "reminder_days_before": days_before,
                "reminder_type": f"auto_{days_before}_day_vaccine_reminder",
                "message": message,
                "status": "sending_by_android_sim",
                "created_at": now_iso(),
                "source_vaccination_record": vaccination_doc_id,
                "gateway_note": "Scheduled reminder picked up by Android SIM gateway"
            })

            try:
                sent_to = send_sms(phone, message)
                update_reminder_status(
                    reminder_id,
                    "sent_by_android_sim",
                    f"Scheduled {days_before}-day reminder sent to {sent_to}"
                )
                sent_count += 1
                print(f"Scheduled {days_before}-day reminder sent for child:", child_id)

            except Exception as sms_error:
                print("Scheduled SMS failed:", sms_error)
                update_reminder_status(reminder_id, "failed_sms_send", str(sms_error))

    return sent_count


def check_environment():
    if API_KEY == "PASTE_FIREBASE_WEB_API_KEY_HERE" or not API_KEY:
        print("ERROR: FIREBASE_WEB_API_KEY is not set.")
        print('Run: export FIREBASE_WEB_API_KEY="YOUR_FIREBASE_API_KEY"')
        return False

    return True


def main():
    print("==============================================")
    print("VaxID Android SIM SMS Gateway")
    print("Scheduled Reminder Version")
    print("==============================================")
    print("Project:", PROJECT_ID)
    print("Polling every", POLL_SECONDS, "seconds")
    print("Scheduled reminders:", REMINDER_DAYS_BEFORE)
    print()

    if not check_environment():
        return

    while True:
        try:
            manual_sent = process_generated_reminders()
            scheduled_sent = process_scheduled_vaccine_reminders()

            if manual_sent == 0 and scheduled_sent == 0:
                print("No SMS sent this cycle.")

        except Exception as error:
            print("Gateway error:", error)

        print("Waiting", POLL_SECONDS, "seconds...\n")
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
